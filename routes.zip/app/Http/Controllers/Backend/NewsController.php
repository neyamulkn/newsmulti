<?php

namespace App\Http\Controllers\Backend;

use App\Models\Deshjure;
use App\Models\SubCategory;
use App\Models\Notification;
use App\User;
use App\Models\Category;
use App\Models\MediaGallery;
use App\Models\News;
use App\Http\Controllers\Controller;
use App\Models\Reporter;
use App\Models\Speciality;
use Brian2694\Toastr\Facades\Toastr;
use Faker\Provider\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
class NewsController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(Request $request, $status='')
    {
        $user_id = Auth::user()->id;
//        $get_news = News::with(['category', 'reporter', 'image']);

        $get_news = News::orderBy('news.id', 'desc')->join('users', 'news.user_id', '=', 'users.id')
            ->leftJoin('categories', 'news.category', '=', 'categories.id')
            ->leftJoin('sub_categories', 'news.subcategory', '=', 'sub_categories.id')
            ->leftJoin('media_galleries', 'news.thumb_image', '=', 'media_galleries.id')
            ->where('lang','=', 1)->groupBy('news.id');
        if($status){
            if($status == 'image-missing'){
                $get_news->where('thumb_image', null);
            }
            if($status == 'active'){
                $get_news->where('news.status', 1);
            }if($status == 'pending'){
                $get_news->where('news.status', 0);
            }if($status == 'draft'){
                $get_news->where('news.status', 2);
            }if($status == 'breaking'){
                $get_news->where('news.breaking_news', 1);
            }
        }

        if(!$status && $request->status && $request->status != 'all'){
            $get_news->where('news.status', $request->status);
        }
        if($request->category && $request->category != 'all'){
            $get_news->where('category', $request->category);
        }
        if($request->reporter && $request->reporter != 'all'){
            $get_news->where('news.user_id', $request->reporter);
        }

        if($request->title){
            $get_news->where('news_title', 'LIKE', '%'. $request->title .'%');
        }

        
        if(Auth::user()->role_id != env('ADMIN') && Auth::user()->role_id != env('EDITOR')){
            $get_news->where('news.user_id', $user_id);
        }
        $perPage = 15;
        if($request->show){
            $perPage = $request->show;
        }
        $data['get_news'] = $get_news->selectRaw('news.*, users.name, users.username,categories.category_bd,categories.category_en, sub_categories.subcategory_bd,media_galleries.source_path')->paginate($perPage);

        $data['all_news'] = News::where('lang','=', 1)->count();
      
        $data['active_news'] = News::where('status', 1)->where('lang','=', 1)->count();
        $data['draft_news'] = News::where('status', 2)->where('lang','=', 1)->count();
        $data['pending_news'] = News::where('status', 0)->where('lang','=', 1)->count();
        $data['breaking'] = News::where('breaking_news', 1)->where('lang','=', 1)->count();
        $data['image_missing'] = News::where('thumb_image', null)->where('lang','=', 1)->count();

        $data['categories'] = Category::where('status', 1)->get();
        $data['reporters'] = User::where('role_id', 2)->orWhere('role_id', 4)->orWhere('role_id', 5)->get();

        return view('backend.news-list')->with($data);
    }

    public function pending()
    {
        $user_id = Auth::user()->id;
//        $get_news = News::with(['category', 'reporter', 'image']);
        $get_news = DB::table('news')
            ->join('users', 'news.user_id', '=', 'users.id')
            ->leftJoin('categories', 'news.category', '=', 'categories.id')
            ->leftJoin('sub_categories', 'news.subcategory', '=', 'sub_categories.id')
            ->leftJoin('media_galleries', 'news.thumb_image', '=', 'media_galleries.id')
            ->where('lang', '=',1)
            ->where('news.status', '=',0);
            if(Auth::user()->role_id != env('ADMIN') && Auth::user()->role_id != env('EDITOR')){
                $get_news = $get_news->where('news.user_id', $user_id);
            }
        $get_news = $get_news->select('news.*','users.name','users.username', 'categories.category_bd', 'categories.category_en', 'sub_categories.subcategory_bd', 'media_galleries.source_path')
            ->orderBy('news.created_at', 'DESC')->paginate(25);
        return view('backend.news-list')->with(compact('get_news'));
    }

    public function draft()
    {
        $user_id = Auth::user()->id;
        $get_news = DB::table('news')
            ->join('users', 'news.user_id', '=', 'users.id')
            ->leftJoin('categories', 'news.category', '=', 'categories.id')
            ->leftJoin('sub_categories', 'news.subcategory', '=', 'sub_categories.id')
            ->leftJoin('media_galleries', 'news.thumb_image', '=', 'media_galleries.id')
            ->where('lang', '=',1)
            ->where('news.status', '=',2);
            if(Auth::user()->role_id != 1){
                $get_news = $get_news->where('news.user_id', $user_id);
            }
        $get_news = $get_news->select('news.*','users.name','users.username', 'categories.category_bd', 'categories.category_en', 'sub_categories.subcategory_bd', 'media_galleries.source_path')
            ->orderBy('news.created_at', 'DESC')->paginate(25);
        return view('backend.news-list')->with(compact('get_news'));
    }

    public function create()
    {
        $data = [];
        $data['categories'] = Category::where('status', 1)->orderBy('serial', 'ASC')->get();
        $data['reporters'] = User::where('role_id',  env('REPORTER'))->orWhere('role_id', env('GENERAL_REPORTER'))->orWhere('role_id', env('ADMIN'))->get();
        
        return view('backend.news')->with($data);
    }

    public function selectImage(Request $request){
        $getImage = MediaGallery::find($request->imageId);
        $user_id = Auth::user()->id;
        $data = [
            'title' => $request->image_title,
            'user_id' => $user_id,
        ];
        MediaGallery::where('id', $getImage->id)->update($data);
        echo 'fsdf';
    }

    public function store(Request $request)
    {
        //news is draft
        if($request->submit == 'draft'){
            $request->validate([
            'news_title' => 'required',
            ]);
        }else{
            $request->validate([
                'news_title' => 'required',
                'news_dsc' => 'required',
                'category' => 'required',
                'image' => 'required',
            ]);
        }

        $user_id = Auth::user()->id;
        if($request->has('user_id')){ $user_id = $request->user_id; }
            if($request->news_slug){
                $news_slug =  $this->createSlug($request->news_slug);
            }else{
                $news_slug =  $this->createSlug($request->news_title);
            }

            $news_data = new News();
            $news_data->news_title = $request->news_title;
            $news_data->news_slug = $news_slug;
            $news_data->news_dsc = $request->news_dsc;
            $news_data->category = $request->category;
            $news_data->subcategory = ($request->subcategory) ? $request->subcategory : null;
            $news_data->child_cat = ($request->district) ? $request->district : null;
            $news_data->subchild_cat = ($request->upzilla) ? $request->upzilla : null;
            $news_data->user_id = $user_id;
            $news_data->lang =  $request->lang;
            $news_data->type = $request->type;
            $news_data->breaking_news = ($request->breaking_news) ? '1' : '0';
            $news_data->publish_date = ($request->publish_date) ? $request->publish_date : Carbon::parse(now());
            
            if($request->has('image')){
                $news_data->thumb_image = $request->image;
            }

            $news_data->keywords = ($request->keywords) ? implode(',', $request->keywords) : '';

            if($request->submit != 'draft'){
                $news_data->status = (isset($request->status)) ? 1 : '0';
            }else{
                $news_data->status = 2;
            }

            $success = $news_data->save();

            if($success){
                if($request->hasFile('attach_files')){
                    $attach_files = $request->file('attach_files');
                    foreach ($attach_files as $attach_file) {

                        $new_name = $this->uniquePath($attach_file->getClientOriginalName());
                        $attach_file->move(public_path('upload/file'), $new_name);
                        $data = [
                            'source_path' => $new_name,
                            'type' => $news_data->id,
                            'user_id' => $user_id,
                        ];
                        $insert = MediaGallery::create($data);
                    }
                }
                // check news post by admin or news is not draft then push notification
                if(Auth::user()->role_id  != env('ADMIN') && $request->submit != 'draft' ){
                    $toUser = User::where('role_id', env('ADMIN'))->first();
                    $notify = [
                        'fromUser' => $user_id,
                        'toUser' => $toUser->id,
                        'type' => env('NEWS'),
                        'item_id' => $news_data->id,
                        'notify' => 'posting news',
                    ];
                    Notification::create($notify);
                }
                Toastr::success('News is '.$request->submit.' successfully.');
            }else{
                Toastr::error('Sorry news inserted faield. ');
            }
            
        return redirect()->back();

    }

    public function edit($news_slug)
    {
        $user_id = Auth::user()->id;
        $data = [];
        $data['categories'] = Category::where('status', 1)->get();
        $data['reporters'] = User::where('role_id', env('REPORTER'))->orWhere('role_id', env('GENERAL_REPORTER'))->orWhere('role_id', env('ADMIN'))->get();

        $find_news = News::with(['image'])->where('news_slug', $news_slug);
        if(Auth::user()->role_id != 1 && Auth::user()->role_id != env('EDITOR')){
            $find_news =  $find_news->where('user_id', $user_id);
        }
        $data['get_news'] =  $find_news->first();

        if($find_news){
            $data['get_subcategories'] = SubCategory::where('category_id',  $data['get_news']->category)->get();
            $data['get_districts'] = Deshjure::where('parent_id',  $data['get_news']->subcategory)->where('cat_type', 1)->get();
            $data['get_upzillas'] = Deshjure::where('parent_id',  $data['get_news']->child_cat)->where('cat_type', 2)->get();

            return view('backend.news-edit')->with($data);
        }else{
            Toastr::error('Sorry news not found.');
            return back();
        }

    }

    public function update(Request $request, $id)
    {

        $news_update = News::where('id', $id)->first();

        //news is draft
        if($request->submit == 'draft'){
            $request->validate([
            'news_title' => 'required',
            ]);
        }else{
            $request->validate([
                'news_title' => 'required',
                'news_dsc' => 'required',
                'category' => 'required',
            ]);
        }

        $user_id = Auth::user()->id;
        if($request->has('user_id')){ $user_id = $request->user_id; }
        $news_slug =  $this->createSlug($request->news_slug);
        $news_update->news_title = $request->news_title;
        if($request->news_slug){
            $news_update->news_slug = $news_slug;
        }
        $news_update->news_dsc = $request->news_dsc;
        $news_update->category = $request->category;
        $news_update->subcategory = ($request->subcategory) ? $request->subcategory : null;
        $news_update->child_cat = ($request->district) ? $request->district : null;
        $news_update->subchild_cat = ($request->upzilla) ? $request->upzilla : null;
        $news_update->user_id = $user_id;
        $news_update->lang =  $request->lang;
        $news_update->type = $request->type;
        $news_update->breaking_news = ($request->breaking_news) ? '1' : '0';

        if($request->has('publish_date')){
            $news_update->publish_date = $request->publish_date;
        }
        if(!empty($request->image)){
            $news_update->thumb_image = $request->image;
        }

        $news_update->keywords = ($request->keywords) ? implode(',', $request->keywords) : '';
       
        if($request->submit != 'draft'){
            $news_update->status = (isset($request->status) ? 1 : '0');
        }else{
            $news_update->status = 2;
        }

        $success = $news_update->save();

        if($success){
            if($request->hasFile('attach_files')){
                $attach_files = $request->file('attach_files');
                foreach ($attach_files as $attach_file) {

                    $new_name = $this->uniquePath($attach_file->getClientOriginalName());
                    $attach_file->move(public_path('upload/file'), $new_name);
                    $data = [
                        'source_path' => $new_name,
                        'type' => $news_update->id,
                        'user_id' => $user_id,
                    ];
                    $insert = MediaGallery::create($data);
                }
            }
            Toastr::success('News is ' .$request->submit. ' successfully.');
        }else{
            Toastr::error('Sorry news updated faield.');
        }
        return redirect()->back();


    }

    public function delete($id)
    {
        $delete =  News::find($id)->delete();
        if($delete){
           
            $output = [
                'status' => true,
                'msg' => 'News delete successfull.'
            ];

        }else{
            $output = [
                'status' => false,
                'msg' => 'Sorry news can\'t deleted.'
            ];
        }
        return response()->json($output);
    }


    public function deleteAttachFile($id){
        $newsFile = MediaGallery::find($id);
        //delete newsFile from store folder
        $file_path = public_path('upload/file/'. $newsFile->source_path);
        if(file_exists($file_path)){
            unlink($file_path);
        }
        // delete image from database
        $delete = $newsFile->delete();
        if($delete){
            echo "Image deleted successfull.";
        }else{
            echo "Sorry image delete failed.!";
        }
    }


    public function status($status){
        $status = News::find($status);
        if($status){
            if($status->status == 1){
                $status->update(['status' => 0]);
                $output = array( 'status' => 'unpublish',  'message'  => 'News Unpublished');
            }else{
                $status->update(['status' => 1]);
                $output = array( 'status' => 'publish',  'message'  => 'News Published');
            }

            $fromUser = User::where('role_id', env('ADMIN'))->first();
            $notify = [
                'fromUser' => $fromUser->id,
                'toUser' => $status->user_id,
                'type' => env('NEWS'),
                'item_id' => $status->id,
                'notify' => $output['message'],
            ];
            Notification::create($notify);
        }
        return response()->json($output);
    }
    public function breaking_news($status){
        $status = News::find($status);
        if($status->breaking_news == 1){
            $status->update(['breaking_news' => 0]);
            $output = array( 'status' => 'remove',  'message'  => 'Remove From Breaking News');
        }else{
            $status->update(['breaking_news' => 1]);
            $output = array( 'status' => 'added',  'message'  => 'Added To Breaking News');
        }

        return response()->json($output);
    }

    public function createSlug($slug=null)
    {
        //$slug = Str::slug($slug);
        $slug = strTolower(preg_replace('/[\s]+/', '-', trim($slug)));
        $slug = (preg_replace("/[?.,'&\/]+/", "", trim($slug)));
    
        $check_slug = News::select('news_slug')->where('news_slug', 'like', $slug.'%')->get();

        if (count($check_slug)>1){
            //find slug until find not used.
            for ($i = 1; $i <= count($check_slug); $i++) {
                $newSlug = $slug.'-'.$i;
                if (!$check_slug->contains('news_slug', $newSlug)) {
                    return $newSlug;
                }
            }
        }else{ return $slug; }
    }

    public function uniquePath($path)
    {

        $check_path = MediaGallery::select('source_path')->where('source_path', 'like', $path.'%')->get();

        if (count($check_path)>0){
            //find slug until find not used.
            for ($i = 1; $i <= count($check_path); $i++) {
                $newPath = $i.'-'.$path;
                if (!$check_path->contains('news_slug', $newPath)) {
                    return $newPath;
                }
            }
        }else{ return $path; }
    }

    public function videoUpload(Request $request)
        {
         $rules = array(
          'uploadFile'  => 'required'
         );

         $error = Validator::make($request->all(), $rules);

         if($error->fails())
         {
            return response()->json(['errors' => $error->errors()->all()]);
         }
         $uploadFile = $request->file('uploadFile');

         $new_name = rand() . '.' . $uploadFile->getClientOriginalExtension();
         $uploadFile->move(public_path('theme/zipfile'), $new_name);

        $theme_url = $request->theme_url;
        $data = ['main_file' => $new_name ];
        $insert_id = theme::where('theme_url',  $theme_url)->update($data);
         $output = array(
             'success' => '<span  onclick="remove_item('.$new_name.')" class="button dark-light square">
                    <img src="'.asset('/allscript/images/dashboard/close-icon-small.png').'" alt="close-icon">
                  </span>',
             'image'  => '<input type="hidden" form="main_form" name="main_file" value="'.$new_name.'"><a href="'.$new_name.'"/><i class="fa fa-paperclip" aria-hidden="true"></i> '.$new_name.' </a>'
            );

          return response()->json($output);
    }

     function image_upload(Request $request)
        {
            $rules = array(
                'phato'  => 'required|max:2048'
            );

            $error = Validator::make($request->all(), $rules);

            if($error->fails())
            {
                return response()->json(['errors' => $error->errors()->all()]);
            }
            $user_id = Auth::user()->id;
            $image_name = null;
            if($request->hasFile('phato')){
                $image = $request->file('phato');
                $image_name = time().rand('123456', '999999').".".$image->getClientOriginalExtension();
                $image_path = public_path('upload/images/thumb_img/'.$image_name );
                $image_resize = Image::make($image);
                $image_resize->resize(200, 115);
                $image_resize->save($image_path);
                $image_path = public_path('upload/images/'.$image_name );
                Image::make($image)->save($image_path);
            }
            $data = [
                'source_path' => $image_name,
                'type' => 1,
                'user_id' => $user_id,
            ];
            $insert = MediaGallery::create($data);
            $output = array(
                'success' => '<a href="#" onclick="remove_file('.$image_name.')" class="button dark-light square"></a>',
                'image'  => '<input type="file" class="dropify" onchange="uploadselectImage()" name="phato" id="input-file-events" data-default-file="'.asset('upload/images/'.$image_name).'">'
            );
            return response()->json($output);
        }



}
