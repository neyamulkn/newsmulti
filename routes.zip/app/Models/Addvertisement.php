<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Addvertisement extends Model
{
    protected $guarded = [];
}
